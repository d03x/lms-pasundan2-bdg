<?php

namespace App;

class LoginRequestDto
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
