<script setup lang="ts">
import IcOutlineMenu from '@/icons/IcOutlineMenu.vue';

</script>

<template>
    <IcOutlineMenu class="h-7 w-7  aspect-square"/>
</template>