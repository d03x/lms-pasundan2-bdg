import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\LoginController::check
 * @see app/Http/Controllers/LoginController.php:18
 * @route '/login'
 */
export const check = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: check.url(options),
    method: 'post',
})

check.definition = {
    methods: ["post"],
    url: '/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoginController::check
 * @see app/Http/Controllers/LoginController.php:18
 * @route '/login'
 */
check.url = (options?: RouteQueryOptions) => {
    return check.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoginController::check
 * @see app/Http/Controllers/LoginController.php:18
 * @route '/login'
 */
check.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: check.url(options),
    method: 'post',
})
const login = {
    check: Object.assign(check, check),
}

export default login