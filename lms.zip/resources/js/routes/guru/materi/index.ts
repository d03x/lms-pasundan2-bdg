import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults, validateParameters } from './../../../wayfinder'
import tambah32e220 from './tambah'
/**
* @see \App\Http\Controllers\GuruMateriController::tambah
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
export const tambah = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tambah.url(args, options),
    method: 'get',
})

tambah.definition = {
    methods: ["get","head"],
    url: '/guru/materi/{kelas_kode?}/tambah-materi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GuruMateriController::tambah
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
tambah.url = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kelas_kode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    kelas_kode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "kelas_kode",
        ])

    const parsedArgs = {
                        kelas_kode: args?.kelas_kode,
                }

    return tambah.definition.url
            .replace('{kelas_kode?}', parsedArgs.kelas_kode?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::tambah
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
tambah.get = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tambah.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GuruMateriController::tambah
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
tambah.head = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tambah.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GuruMateriController::deleteMethod
 * @see app/Http/Controllers/GuruMateriController.php:155
 * @route '/guru/delete-materi/{materi_id}'
 */
export const deleteMethod = (args: { materi_id: string | number } | [materi_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

deleteMethod.definition = {
    methods: ["delete"],
    url: '/guru/delete-materi/{materi_id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GuruMateriController::deleteMethod
 * @see app/Http/Controllers/GuruMateriController.php:155
 * @route '/guru/delete-materi/{materi_id}'
 */
deleteMethod.url = (args: { materi_id: string | number } | [materi_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { materi_id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    materi_id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        materi_id: args.materi_id,
                }

    return deleteMethod.definition.url
            .replace('{materi_id}', parsedArgs.materi_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::deleteMethod
 * @see app/Http/Controllers/GuruMateriController.php:155
 * @route '/guru/delete-materi/{materi_id}'
 */
deleteMethod.delete = (args: { materi_id: string | number } | [materi_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\GuruMateriController::publish
 * @see app/Http/Controllers/GuruMateriController.php:170
 * @route '/guru/publish-materi'
 */
export const publish = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(options),
    method: 'patch',
})

publish.definition = {
    methods: ["patch"],
    url: '/guru/publish-materi',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\GuruMateriController::publish
 * @see app/Http/Controllers/GuruMateriController.php:170
 * @route '/guru/publish-materi'
 */
publish.url = (options?: RouteQueryOptions) => {
    return publish.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::publish
 * @see app/Http/Controllers/GuruMateriController.php:170
 * @route '/guru/publish-materi'
 */
publish.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(options),
    method: 'patch',
})
const materi = {
    tambah: Object.assign(tambah, tambah32e220),
delete: Object.assign(deleteMethod, deleteMethod),
publish: Object.assign(publish, publish),
}

export default materi