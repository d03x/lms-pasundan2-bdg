import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults, validateParameters } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GuruMateriController::simpan
 * @see app/Http/Controllers/GuruMateriController.php:130
 * @route '/guru/materi/{kelas_kode?}/simpan-materi'
 */
export const simpan = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simpan.url(args, options),
    method: 'post',
})

simpan.definition = {
    methods: ["post"],
    url: '/guru/materi/{kelas_kode?}/simpan-materi',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GuruMateriController::simpan
 * @see app/Http/Controllers/GuruMateriController.php:130
 * @route '/guru/materi/{kelas_kode?}/simpan-materi'
 */
simpan.url = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kelas_kode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    kelas_kode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "kelas_kode",
        ])

    const parsedArgs = {
                        kelas_kode: args?.kelas_kode,
                }

    return simpan.definition.url
            .replace('{kelas_kode?}', parsedArgs.kelas_kode?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::simpan
 * @see app/Http/Controllers/GuruMateriController.php:130
 * @route '/guru/materi/{kelas_kode?}/simpan-materi'
 */
simpan.post = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simpan.url(args, options),
    method: 'post',
})
const tambah = {
    simpan: Object.assign(simpan, simpan),
}

export default tambah