import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults, validateParameters } from './../../wayfinder'
import materiFa2873 from './materi'
/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
export const materi = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materi.url(args, options),
    method: 'get',
})

materi.definition = {
    methods: ["get","head"],
    url: '/guru/materi/{kelas_kode?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
materi.url = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kelas_kode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    kelas_kode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "kelas_kode",
        ])

    const parsedArgs = {
                        kelas_kode: args?.kelas_kode,
                }

    return materi.definition.url
            .replace('{kelas_kode?}', parsedArgs.kelas_kode?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
materi.get = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materi.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
materi.head = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: materi.url(args, options),
    method: 'head',
})
const guru = {
    materi: Object.assign(materi, materiFa2873),
}

export default guru