import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../wayfinder'
/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::__invoke
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::__invoke
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::__invoke
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::__invoke
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\NotifServiceController::saveFcmToken
 * @see app/Http/Controllers/NotifServiceController.php:9
 * @route '/fcm-cloud/save-fcm-token'
 */
export const saveFcmToken = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFcmToken.url(options),
    method: 'post',
})

saveFcmToken.definition = {
    methods: ["post"],
    url: '/fcm-cloud/save-fcm-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotifServiceController::saveFcmToken
 * @see app/Http/Controllers/NotifServiceController.php:9
 * @route '/fcm-cloud/save-fcm-token'
 */
saveFcmToken.url = (options?: RouteQueryOptions) => {
    return saveFcmToken.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotifServiceController::saveFcmToken
 * @see app/Http/Controllers/NotifServiceController.php:9
 * @route '/fcm-cloud/save-fcm-token'
 */
saveFcmToken.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFcmToken.url(options),
    method: 'post',
})