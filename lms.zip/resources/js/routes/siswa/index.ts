import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
import materiFa2873 from './materi'
/**
* @see \App\Http\Controllers\MateriController::materi
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
export const materi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materi.url(options),
    method: 'get',
})

materi.definition = {
    methods: ["get","head"],
    url: '/siswa/materi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MateriController::materi
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
materi.url = (options?: RouteQueryOptions) => {
    return materi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MateriController::materi
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
materi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MateriController::materi
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
materi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: materi.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
export const tugas = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tugas.url(options),
    method: 'get',
})

tugas.definition = {
    methods: ["get","head"],
    url: '/siswa/tugas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
tugas.url = (options?: RouteQueryOptions) => {
    return tugas.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
tugas.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tugas.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
tugas.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tugas.url(options),
    method: 'head',
})
const siswa = {
    materi: Object.assign(materi, materiFa2873),
tugas: Object.assign(tugas, tugas),
}

export default siswa