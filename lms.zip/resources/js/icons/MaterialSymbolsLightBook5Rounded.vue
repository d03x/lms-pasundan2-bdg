
<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Material Symbols Light by Google - https://github.com/google/material-design-icons/blob/master/LICENSE --><path fill="currentColor" d="M6.98 21q-.816 0-1.398-.541Q5 19.917 5 19.119V5.766q0-.778.53-1.364t1.306-.748l6.828-1.437q.751-.161 1.351.314t.6 1.252V15.11q0 .572-.363 1.01t-.91.562l-7.586 1.651q-.302.07-.529.276T6 19.12q0 .39.292.635t.689.245h10.404q.269 0 .442-.173t.173-.443V5.5q0-.213.143-.357T18.5 5t.357.143T19 5.5v13.885q0 .67-.472 1.143q-.472.472-1.143.472zm1.009-3.938q.177-.037.286-.168t.11-.307V4.969q0-.244-.18-.39t-.424-.085q-.177.037-.287.168q-.11.13-.11.307v11.618q0 .244.18.39t.424.085" /></svg>
</template>

<script>
export default {
  name: 'MaterialSymbolsLightBook5Rounded'
}
</script>