
<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Material Symbols by Google - https://github.com/google/material-design-icons/blob/master/LICENSE --><path fill="currentColor" d="M19 8q-1.25 0-2.125-.875T16 5t.875-2.125T19 2t2.125.875T22 5t-.875 2.125T19 8m-7 14q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2q.7 0 1.388.1t1.362.3q-.275.425-.45.913t-.25.987q-.5-.15-1.012-.225T12 4Q8.65 4 6.325 6.325T4 12t2.325 5.675T12 20t5.675-2.325T20 12q0-.525-.075-1.037T19.7 9.95q.5-.075.988-.25t.912-.45q.2.675.3 1.363T22 12q0 2.075-.787 3.9t-2.138 3.175t-3.175 2.138T12 22m-1.425-5.4L17.4 9.775q-.5-.175-.937-.437t-.838-.613L10.6 13.75l-2.85-2.8l-1.4 1.4z" /></svg>
</template>

<script>
export default {
  name: 'MaterialSymbolsCheckCircleUnreadOutline'
}
</script>