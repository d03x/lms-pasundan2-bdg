import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
const LoginController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: LoginController.url(options),
    method: 'get',
})

LoginController.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
LoginController.url = (options?: RouteQueryOptions) => {
    return LoginController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
LoginController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: LoginController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoginController::__invoke
 * @see app/Http/Controllers/LoginController.php:14
 * @route '/login'
 */
LoginController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: LoginController.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LoginController::checkLogin
 * @see app/Http/Controllers/LoginController.php:18
 * @route '/login'
 */
export const checkLogin = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkLogin.url(options),
    method: 'post',
})

checkLogin.definition = {
    methods: ["post"],
    url: '/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoginController::checkLogin
 * @see app/Http/Controllers/LoginController.php:18
 * @route '/login'
 */
checkLogin.url = (options?: RouteQueryOptions) => {
    return checkLogin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoginController::checkLogin
 * @see app/Http/Controllers/LoginController.php:18
 * @route '/login'
 */
checkLogin.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkLogin.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LoginController::logout
 * @see app/Http/Controllers/LoginController.php:28
 * @route '/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logout.url(options),
    method: 'get',
})

logout.definition = {
    methods: ["get","head"],
    url: '/logout',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoginController::logout
 * @see app/Http/Controllers/LoginController.php:28
 * @route '/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoginController::logout
 * @see app/Http/Controllers/LoginController.php:28
 * @route '/logout'
 */
logout.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logout.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoginController::logout
 * @see app/Http/Controllers/LoginController.php:28
 * @route '/logout'
 */
logout.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logout.url(options),
    method: 'head',
})
LoginController.checkLogin = checkLogin
LoginController.logout = logout

export default LoginController