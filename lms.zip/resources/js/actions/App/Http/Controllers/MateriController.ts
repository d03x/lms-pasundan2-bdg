import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MateriController::showMateri
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
export const showMateri = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showMateri.url(options),
    method: 'get',
})

showMateri.definition = {
    methods: ["get","head"],
    url: '/siswa/materi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MateriController::showMateri
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
showMateri.url = (options?: RouteQueryOptions) => {
    return showMateri.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MateriController::showMateri
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
showMateri.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showMateri.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MateriController::showMateri
 * @see app/Http/Controllers/MateriController.php:14
 * @route '/siswa/materi'
 */
showMateri.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showMateri.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MateriController::view
 * @see app/Http/Controllers/MateriController.php:53
 * @route '/siswa/materi/{id}'
 */
export const view = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(args, options),
    method: 'get',
})

view.definition = {
    methods: ["get","head"],
    url: '/siswa/materi/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MateriController::view
 * @see app/Http/Controllers/MateriController.php:53
 * @route '/siswa/materi/{id}'
 */
view.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return view.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MateriController::view
 * @see app/Http/Controllers/MateriController.php:53
 * @route '/siswa/materi/{id}'
 */
view.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MateriController::view
 * @see app/Http/Controllers/MateriController.php:53
 * @route '/siswa/materi/{id}'
 */
view.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: view.url(args, options),
    method: 'head',
})
const MateriController = { showMateri, view }

export default MateriController