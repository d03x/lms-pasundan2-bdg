import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NotifServiceController::saveFcmToken
 * @see app/Http/Controllers/NotifServiceController.php:9
 * @route '/fcm-cloud/save-fcm-token'
 */
export const saveFcmToken = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFcmToken.url(options),
    method: 'post',
})

saveFcmToken.definition = {
    methods: ["post"],
    url: '/fcm-cloud/save-fcm-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotifServiceController::saveFcmToken
 * @see app/Http/Controllers/NotifServiceController.php:9
 * @route '/fcm-cloud/save-fcm-token'
 */
saveFcmToken.url = (options?: RouteQueryOptions) => {
    return saveFcmToken.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotifServiceController::saveFcmToken
 * @see app/Http/Controllers/NotifServiceController.php:9
 * @route '/fcm-cloud/save-fcm-token'
 */
saveFcmToken.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveFcmToken.url(options),
    method: 'post',
})
const NotifServiceController = { saveFcmToken }

export default NotifServiceController