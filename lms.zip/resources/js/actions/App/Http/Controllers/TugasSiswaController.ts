import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
const TugasSiswaController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: TugasSiswaController.url(options),
    method: 'get',
})

TugasSiswaController.definition = {
    methods: ["get","head"],
    url: '/siswa/tugas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
TugasSiswaController.url = (options?: RouteQueryOptions) => {
    return TugasSiswaController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
TugasSiswaController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: TugasSiswaController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TugasSiswaController::__invoke
 * @see app/Http/Controllers/TugasSiswaController.php:9
 * @route '/siswa/tugas'
 */
TugasSiswaController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: TugasSiswaController.url(options),
    method: 'head',
})
export default TugasSiswaController