import LoginController from './LoginController'
import DashboardController from './DashboardController'
import MateriController from './MateriController'
import TugasSiswaController from './TugasSiswaController'
import GuruMateriController from './GuruMateriController'
import NotifServiceController from './NotifServiceController'
const Controllers = {
    LoginController: Object.assign(LoginController, LoginController),
DashboardController: Object.assign(DashboardController, DashboardController),
MateriController: Object.assign(MateriController, MateriController),
TugasSiswaController: Object.assign(TugasSiswaController, TugasSiswaController),
GuruMateriController: Object.assign(GuruMateriController, GuruMateriController),
NotifServiceController: Object.assign(NotifServiceController, NotifServiceController),
}

export default Controllers