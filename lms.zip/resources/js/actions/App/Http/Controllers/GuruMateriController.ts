import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults, validateParameters } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
export const materi = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materi.url(args, options),
    method: 'get',
})

materi.definition = {
    methods: ["get","head"],
    url: '/guru/materi/{kelas_kode?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
materi.url = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kelas_kode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    kelas_kode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "kelas_kode",
        ])

    const parsedArgs = {
                        kelas_kode: args?.kelas_kode,
                }

    return materi.definition.url
            .replace('{kelas_kode?}', parsedArgs.kelas_kode?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
materi.get = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materi.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GuruMateriController::materi
 * @see app/Http/Controllers/GuruMateriController.php:35
 * @route '/guru/materi/{kelas_kode?}'
 */
materi.head = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: materi.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GuruMateriController::tambahMateri
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
export const tambahMateri = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tambahMateri.url(args, options),
    method: 'get',
})

tambahMateri.definition = {
    methods: ["get","head"],
    url: '/guru/materi/{kelas_kode?}/tambah-materi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GuruMateriController::tambahMateri
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
tambahMateri.url = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kelas_kode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    kelas_kode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "kelas_kode",
        ])

    const parsedArgs = {
                        kelas_kode: args?.kelas_kode,
                }

    return tambahMateri.definition.url
            .replace('{kelas_kode?}', parsedArgs.kelas_kode?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::tambahMateri
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
tambahMateri.get = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tambahMateri.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GuruMateriController::tambahMateri
 * @see app/Http/Controllers/GuruMateriController.php:89
 * @route '/guru/materi/{kelas_kode?}/tambah-materi'
 */
tambahMateri.head = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tambahMateri.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GuruMateriController::simpanMateri
 * @see app/Http/Controllers/GuruMateriController.php:130
 * @route '/guru/materi/{kelas_kode?}/simpan-materi'
 */
export const simpanMateri = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simpanMateri.url(args, options),
    method: 'post',
})

simpanMateri.definition = {
    methods: ["post"],
    url: '/guru/materi/{kelas_kode?}/simpan-materi',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GuruMateriController::simpanMateri
 * @see app/Http/Controllers/GuruMateriController.php:130
 * @route '/guru/materi/{kelas_kode?}/simpan-materi'
 */
simpanMateri.url = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kelas_kode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    kelas_kode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "kelas_kode",
        ])

    const parsedArgs = {
                        kelas_kode: args?.kelas_kode,
                }

    return simpanMateri.definition.url
            .replace('{kelas_kode?}', parsedArgs.kelas_kode?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::simpanMateri
 * @see app/Http/Controllers/GuruMateriController.php:130
 * @route '/guru/materi/{kelas_kode?}/simpan-materi'
 */
simpanMateri.post = (args?: { kelas_kode?: string | number } | [kelas_kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simpanMateri.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GuruMateriController::deleteMateri
 * @see app/Http/Controllers/GuruMateriController.php:155
 * @route '/guru/delete-materi/{materi_id}'
 */
export const deleteMateri = (args: { materi_id: string | number } | [materi_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMateri.url(args, options),
    method: 'delete',
})

deleteMateri.definition = {
    methods: ["delete"],
    url: '/guru/delete-materi/{materi_id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GuruMateriController::deleteMateri
 * @see app/Http/Controllers/GuruMateriController.php:155
 * @route '/guru/delete-materi/{materi_id}'
 */
deleteMateri.url = (args: { materi_id: string | number } | [materi_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { materi_id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    materi_id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        materi_id: args.materi_id,
                }

    return deleteMateri.definition.url
            .replace('{materi_id}', parsedArgs.materi_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::deleteMateri
 * @see app/Http/Controllers/GuruMateriController.php:155
 * @route '/guru/delete-materi/{materi_id}'
 */
deleteMateri.delete = (args: { materi_id: string | number } | [materi_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMateri.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\GuruMateriController::publishMateri
 * @see app/Http/Controllers/GuruMateriController.php:170
 * @route '/guru/publish-materi'
 */
export const publishMateri = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publishMateri.url(options),
    method: 'patch',
})

publishMateri.definition = {
    methods: ["patch"],
    url: '/guru/publish-materi',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\GuruMateriController::publishMateri
 * @see app/Http/Controllers/GuruMateriController.php:170
 * @route '/guru/publish-materi'
 */
publishMateri.url = (options?: RouteQueryOptions) => {
    return publishMateri.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuruMateriController::publishMateri
 * @see app/Http/Controllers/GuruMateriController.php:170
 * @route '/guru/publish-materi'
 */
publishMateri.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publishMateri.url(options),
    method: 'patch',
})
const GuruMateriController = { materi, tambahMateri, simpanMateri, deleteMateri, publishMateri }

export default GuruMateriController