<template>
    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quam accusamus quis quidem explicabo? Debitis nostrum illum, blanditiis ipsam distinctio
    molestias sint quos autem, natus ullam culpa veniam voluptate, dolores iure.
</template>
